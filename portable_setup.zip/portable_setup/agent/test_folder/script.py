﻿print('hello world')
